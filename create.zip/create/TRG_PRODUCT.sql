REM INSERTING into TRG_PRODUCT
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (3,'JEW',20,'Earrings');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (4,'JEW',90,'Gold Bracelet');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (6,'SPO',30,'Green Sweetshirt');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (2,'WAT',110,'Silver Watch');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (7,'SPO',30,'Red Sweetshirt');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (12,'EQU',30,'Sunglasses');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (8,'SPO',25,'White Sweetshirt');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (10,'EQU',80,'Tennis Racket');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (14,'VAR',18,'Towel');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (1,'WAT',120,'Gold Watch');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (11,'EQU',15,'Tennis Balls');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (9,'SPO',45,'Sport Shoes');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (13,'VAR',5,'Keyring');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (15,'VAR',2,'French Choucroute');
Insert into TRG_PRODUCT (PRODUCT_ID,FAMILY_ID,PRICE,PRODUCT) values (5,'JEW',105,'Silver Collar');
