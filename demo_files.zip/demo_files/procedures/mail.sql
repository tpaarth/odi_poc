CREATE TABLE ODI_MAILING_LIST
(
USER_NAME VARCHAR2(255),
EMAIL VARCHAR2(255)
);


insert into odi_mailing_list values ('Aakash','AAKASH.KAUSHIK@VODAFONE.COM');
insert into odi_mailing_list values ('Aman','AMAN.KOTHIYAL@VODAFONE.COM');
insert into odi_mailing_list values ('Ashmita','ashmita.banik@vodafone.com');
insert into odi_mailing_list values ('Ganesh','GANESH.MALLELA@VODAFONE.COM');
insert into odi_mailing_list values ('Namaratha','NAMARATHA.KARANTH@VODAFONE.COM');
insert into odi_mailing_list values ('Paarth','paarth.tiwari@vodafone.com');
insert into odi_mailing_list values ('Pulkit','PULKIT.SOLANKI@VODAFONE.COM');
insert into odi_mailing_list values ('Sanket','sanket.narke1@vodafone.com');
insert into odi_mailing_list values ('Shridhar','shridhar.pagar@vodafone.com');

CREATE SEQUENCE mail_seq
  MINVALUE 1
  MAXVALUE 999999999999999999999999999
  START WITH 1
  INCREMENT BY 1;
  
  
  
---src cmd---
SELECT email AS mail_id ,
  user_name  AS usr,
  <SEQQ> mailct
FROM odi_mailing_list


---tgt cmd---
OdiSendMail "-MAILHOST=localhost" "-PORT=25" "-FROM=odiadmin" "-SUBJECT=test from odi" "-TO=#mail_id"
Hi #usr

This is a test mail from odi

Regards,
ODI Admin
(email count:#mailct)