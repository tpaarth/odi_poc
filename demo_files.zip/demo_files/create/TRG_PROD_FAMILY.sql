REM INSERTING into TRG_PROD_FAMILY
Insert into TRG_PROD_FAMILY (FAMILY_ID,FAMILY_NAME) values ('EQU','Equipment');
Insert into TRG_PROD_FAMILY (FAMILY_ID,FAMILY_NAME) values ('WAT','Watches');
Insert into TRG_PROD_FAMILY (FAMILY_ID,FAMILY_NAME) values ('JEW','Jewels');
Insert into TRG_PROD_FAMILY (FAMILY_ID,FAMILY_NAME) values ('VAR','Various');
Insert into TRG_PROD_FAMILY (FAMILY_ID,FAMILY_NAME) values ('SPO','Sportswear');
