REM INSERTING into SRC_PRODUCT
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (1,'Gold Watch',120,'Watches');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (2,'Silver Watch',110,'Watches');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (3,'Earrings',20,'Jewels');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (4,'Gold Bracelet',90,'Jewels');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (5,'Silver Collar',105,'Jewels');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (6,'Green Sweetshirt',30,'Sportswear');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (7,'Red Sweetshirt',30,'Sportswear');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (8,'White Sweetshirt',25,'Sportswear');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (9,'Sport Shoes',45,'Sportswear');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (10,'Tennis Racket',80,'Equipment');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (11,'Tennis Balls',15,'Equipment');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (12,'Sunglasses',30,'Equipment');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (13,'Keyring',5,'Various');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (14,'Towel',18,'Various');
Insert into SRC_PRODUCT (PRODUCT_ID,PRODUCT,PRICE,FAMILY_NAME) values (15,'French Choucroute',2,'Various');
